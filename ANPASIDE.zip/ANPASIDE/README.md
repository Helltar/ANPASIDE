ANPASIDE
========

Android Pascal IDE

Мобильная среда разработки использующая компилятор языка программирования [MIDletPascal](http://ru.wikipedia.org/wiki/MIDletPascal).

<a href='https://play.google.com/store/apps/details?id=com.github.helltar.anpaside'><img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png' height='75'/></a>
---
<img src="http://helltar.ho.ua/projects/anpaside/screenshots/Screenshot_20210108-184346_ANPASIDE.png" width="30%"> <img src="http://helltar.ho.ua/projects/anpaside/screenshots/Screenshot_20210108-184403_Android%20System.png" width="30%"> <img src="http://helltar.ho.ua/projects/anpaside/screenshots/Screenshot_20210108-184439_J2ME%20Loader.png" width="30%">
